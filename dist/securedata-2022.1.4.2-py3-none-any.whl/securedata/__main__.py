from securedata import securedata

securedata.main()