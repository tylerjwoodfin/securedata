import securedata

securedata.main()